export const server = "https://eshop-tutorial.vercel.app/api/v2";


